/**
 * SeVIn AI Hub — Frontend Logic
 * Runs against the Flask hub_server.py backend.
 */

'use strict';

// ─── State ──────────────────────────────────────────────────────────────────
const state = {
  agents: [],
  rooms: [],
  tools: [],
  activeAgentId: null,
  activeRoomId: null,
  view: 'agents',      // 'agents' | 'rooms'
  chatHistories: {},   // agentId → [{role,content}]
  roomMessages: {},    // roomId  → [{from, content, color}]
  pendingCommand: null,// CRITICAL: stored before PIN modal opens
  pinBuffer: '',
  speech: null,
  speaking: false,
  socket: null,
};

// ─── DOM refs ────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html) e.innerHTML = html; return e; };

// ─── API helpers ────────────────────────────────────────────────────────────
async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`/api${path}`, opts);
  return res.json();
}
const GET  = path       => api('GET',    path);
const POST = (path, b)  => api('POST',   path, b);
const DEL  = path       => api('DELETE', path);

// ─── Init ────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initSocket();
  loadAll();
  bindGlobalEvents();
});

async function loadAll() {
  await Promise.all([loadAgents(), loadRooms(), loadTools()]);
}

// ─── SocketIO ────────────────────────────────────────────────────────────────
function initSocket() {
  if (typeof io === 'undefined') return;
  state.socket = io({ transports: ['websocket', 'polling'] });
  state.socket.on('message', onSocketMessage);
  state.socket.on('error',   d => console.warn('Socket error:', d));
}

function onSocketMessage(data) {
  if (!state.activeRoomId) return;
  addRoomMessage(state.activeRoomId, {
    from:    data.from,
    content: data.content,
    color:   data.color,
    isUser:  false,
  });
}

// ─── Agents ─────────────────────────────────────────────────────────────────
async function loadAgents() {
  state.agents = await GET('/agents');
  renderAgentList();
  if (state.agents.length && !state.activeAgentId) {
    selectAgent(state.agents[0].id);
  }
}

function renderAgentList() {
  const list = $('agent-list');
  list.innerHTML = '';
  $('agent-count').textContent = state.agents.length;

  state.agents.forEach(agent => {
    const item = el('div', `agent-item${state.activeAgentId === agent.id ? ' active' : ''}`);
    item.style.setProperty('--agent-color', agent.color || '#00f0ff');
    item.dataset.id = agent.id;
    item.innerHTML = `
      <div class="agent-emoji">${agent.emoji || '🤖'}</div>
      <div class="agent-info">
        <div class="agent-name">${esc(agent.name)}</div>
        <div class="agent-status">
          <div class="status-dot ${agent.status || 'online'}"></div>
          <span class="status-text">${agent.status || 'online'}</span>
        </div>
      </div>`;
    item.addEventListener('click', () => selectAgent(agent.id));
    list.appendChild(item);
  });
}

function selectAgent(agentId) {
  state.activeAgentId = agentId;
  state.view = 'agents';
  renderAgentList();
  renderWorkspace();
}

function getAgent(id) { return state.agents.find(a => a.id === id); }

// ─── Workspace Render ────────────────────────────────────────────────────────
function renderWorkspace() {
  const agent = getAgent(state.activeAgentId);

  $('empty-state').classList.toggle('hidden', !!agent || state.view === 'rooms');
  $('chat-panel').classList.toggle('hidden', !agent || state.view === 'rooms');
  $('group-chat-panel').classList.toggle('hidden', state.view !== 'rooms');
  $('side-panels').classList.toggle('hidden', !agent && state.view !== 'rooms');

  if (!agent && state.view !== 'rooms') return;

  if (state.view === 'rooms') {
    renderRoomsPanel();
    return;
  }

  // Topbar
  $('topbar-agent-name').textContent = `${agent.emoji} ${agent.name}`;
  const caps = $('topbar-caps');
  caps.innerHTML = '';
  (agent.capabilities || []).forEach(c => {
    const b = el('span', 'cap-badge active'); b.textContent = c.replace('_', ' '); caps.appendChild(b);
  });

  // Chat header
  $('chat-agent-emoji').textContent = agent.emoji || '🤖';
  $('chat-agent-name').textContent = agent.name;
  $('chat-agent-sub-label').textContent = 'Neural Interface Online';

  // Panels
  const hasTerm  = agent.capabilities?.includes('terminal');
  const hasVoice = agent.capabilities?.includes('voice');

  $('terminal-panel').classList.toggle('hidden', !hasTerm);
  $('voice-panel').classList.toggle('hidden', !hasVoice);

  if (hasTerm) renderTerminalHeader(agent);
  if (hasVoice) setupVoice(agent);

  renderChatHistory(agent.id);
  loadTools();
}

// ─── Chat ────────────────────────────────────────────────────────────────────
function renderChatHistory(agentId) {
  const msgs = $('messages');
  msgs.innerHTML = '';
  (state.chatHistories[agentId] || []).forEach(m => appendMessage(m.role, m.content));
}

function appendMessage(role, content) {
  const agent = getAgent(state.activeAgentId);
  const isUser = role === 'user';
  const msgs = $('messages');

  const wrap = el('div', `message ${isUser ? 'user' : 'agent'}`);

  const avatar = el('div', 'msg-avatar');
  avatar.textContent = isUser ? '👤' : (agent?.emoji || '🤖');

  const contentWrap = el('div', 'msg-content');
  const name = el('div', 'msg-name');
  name.textContent = isUser ? 'You' : (agent?.name || 'Agent');

  const bubble = el('div', 'msg-bubble');
  bubble.textContent = content;

  contentWrap.appendChild(name);
  contentWrap.appendChild(bubble);
  wrap.appendChild(avatar);
  wrap.appendChild(contentWrap);
  msgs.appendChild(wrap);
  msgs.scrollTop = msgs.scrollHeight;
  return bubble;
}

function appendTyping() {
  const agent = getAgent(state.activeAgentId);
  const msgs = $('messages');
  const wrap = el('div', 'message agent');
  const avatar = el('div', 'msg-avatar'); avatar.textContent = agent?.emoji || '🤖';
  const contentWrap = el('div', 'msg-content');
  const name = el('div', 'msg-name'); name.textContent = agent?.name || 'Agent';
  const bubble = el('div', 'msg-bubble typing');
  bubble.innerHTML = '<span class="typing-dots">Thinking</span>';
  contentWrap.appendChild(name); contentWrap.appendChild(bubble);
  wrap.appendChild(avatar); wrap.appendChild(contentWrap);
  msgs.appendChild(wrap);
  msgs.scrollTop = msgs.scrollHeight;
  return wrap;
}

async function sendMessage() {
  const input = $('chat-input');
  const text = input.value.trim();
  if (!text || !state.activeAgentId) return;

  input.value = '';
  input.style.height = 'auto';

  const agent = getAgent(state.activeAgentId);
  if (!state.chatHistories[state.activeAgentId]) state.chatHistories[state.activeAgentId] = [];
  const history = state.chatHistories[state.activeAgentId];

  history.push({ role: 'user', content: text });
  appendMessage('user', text);

  const typing = appendTyping();
  $('btn-send').disabled = true;

  try {
    const res = await POST(`/agents/${state.activeAgentId}/chat`, {
      message: text,
      history: history.slice(-20),
    });
    typing.remove();
    const reply = res.message || res.error || 'No response';
    history.push({ role: 'assistant', content: reply });
    appendMessage('assistant', reply);

    // Auto TTS if voice enabled
    if (agent?.capabilities?.includes('voice') && !$('voice-panel').classList.contains('hidden')) {
      speakText(state.activeAgentId, reply);
    }
  } catch (e) {
    typing.remove();
    appendMessage('assistant', `[Error: ${e.message}]`);
  } finally {
    $('btn-send').disabled = false;
    input.focus();
  }
}

// ─── Terminal ────────────────────────────────────────────────────────────────
function renderTerminalHeader(agent) {
  $('terminal-agent-label').textContent = `SYS_TERM // ${agent.name.toUpperCase()}`;
}

function termPrint(text, cls = '') {
  const out = $('terminal-output');
  const line = el('div', `term-line ${cls}`);
  line.textContent = text;
  out.appendChild(line);
  out.scrollTop = out.scrollHeight;
}

function runTerminalCommand() {
  const input = $('terminal-input');
  const cmd = input.value.trim();
  if (!cmd) return;
  input.value = '';

  termPrint(`$ ${cmd}`, 'cmd');

  // CRITICAL: Store the command BEFORE showing PIN modal
  // This prevents command loss if user types new text
  state.pendingCommand = cmd;
  openPinModal();
}

async function executePendingCommand(pin) {
  const cmd = state.pendingCommand;
  if (!cmd) return;
  state.pendingCommand = null;

  try {
    const res = await POST('/terminal/exec', { command: cmd, pin });
    if (res.error) {
      termPrint(`Error: ${res.error}`, 'err');
    } else {
      const lines = (res.output || '').split('\n');
      lines.forEach(l => termPrint(l));
      if (res.exitCode !== 0) termPrint(`[exit ${res.exitCode}]`, 'err');
    }
  } catch (e) {
    termPrint(`[Connection error: ${e.message}]`, 'err');
  }
}

// ─── Voice ───────────────────────────────────────────────────────────────────
function setupVoice(agent) {
  $('wake-word-label').textContent = `Say "Hey ${agent.name}"`;
  $('voice-status-text').textContent = 'VOICE LINK STANDBY';
}

function toggleVoice() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    $('voice-transcript').textContent = 'Speech recognition not supported in this browser.';
    return;
  }

  if (state.speech && state.speaking) {
    state.speech.stop();
    state.speaking = false;
    $('voice-btn').classList.remove('listening');
    $('voice-status-text').textContent = 'VOICE LINK STANDBY';
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = 'en-US';
  state.speech = recognition;
  state.speaking = true;

  $('voice-btn').classList.add('listening');
  $('voice-status-text').textContent = 'LISTENING...';

  const agent = getAgent(state.activeAgentId);
  const wakeWord = `hey ${agent?.name?.toLowerCase() || ''}`;

  recognition.onresult = async (e) => {
    let transcript = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      transcript += e.results[i][0].transcript;
    }
    $('voice-transcript').textContent = transcript;

    const isFinal = e.results[e.results.length - 1].isFinal;
    if (isFinal) {
      const lower = transcript.toLowerCase();
      const triggered = wakeWord ? lower.includes(wakeWord) : true;
      const query = triggered ? transcript.replace(new RegExp(wakeWord, 'i'), '').trim() : transcript.trim();

      if (query) {
        $('voice-status-text').textContent = 'PROCESSING...';
        $('chat-input').value = query;
        await sendMessage();
        $('voice-status-text').textContent = 'LISTENING...';
      }
    }
  };

  recognition.onerror = (e) => {
    $('voice-status-text').textContent = `ERROR: ${e.error}`;
    state.speaking = false;
    $('voice-btn').classList.remove('listening');
  };

  recognition.onend = () => {
    if (state.speaking) recognition.start(); // restart for continuous
  };

  recognition.start();
}

async function speakText(agentId, text) {
  try {
    const res = await POST(`/agents/${agentId}/tts`, { text, lang: 'en' });
    if (res.audioUrl) {
      const audio = new Audio(res.audioUrl);
      audio.play().catch(() => {});
    }
  } catch (_) {}
}

// ─── Group Chat / Rooms ──────────────────────────────────────────────────────
async function loadRooms() {
  state.rooms = await GET('/rooms');
  renderRoomsList();
}

function renderRoomsList() {
  const list = $('rooms-sidebar-list');
  if (!list) return;
  list.innerHTML = '';
  state.rooms.forEach(room => {
    const item = el('div', `room-item${state.activeRoomId === room.id ? ' active' : ''}`);
    item.innerHTML = `
      <div>
        <div class="room-name"># ${esc(room.name)}</div>
        <div class="room-agents">${room.agentIds.length} agents</div>
      </div>
      <button class="btn btn-sm btn-danger" onclick="deleteRoom('${room.id}')">✕</button>`;
    item.querySelector('.room-name').addEventListener('click', () => openRoom(room.id));
    list.appendChild(item);
  });
}

function openRoom(roomId) {
  state.activeRoomId = roomId;
  state.view = 'rooms';
  if (state.socket) {
    state.socket.emit('join_room', { room: roomId });
  }
  renderRoomsList();
  renderWorkspace();
}

function renderRoomsPanel() {
  const room = state.rooms.find(r => r.id === state.activeRoomId);
  if (!room) return;
  $('group-room-name').textContent = `# ${room.name}`;
  renderGroupMessages(room.id);
}

function addRoomMessage(roomId, msg) {
  if (!state.roomMessages[roomId]) state.roomMessages[roomId] = [];
  state.roomMessages[roomId].push(msg);
  if (state.activeRoomId === roomId && state.view === 'rooms') {
    renderGroupMessages(roomId);
  }
}

function renderGroupMessages(roomId) {
  const container = $('group-messages');
  container.innerHTML = '';
  (state.roomMessages[roomId] || []).forEach(msg => {
    const item = el('div', `group-msg ${msg.isUser ? 'user-msg' : ''}`);
    item.innerHTML = `
      <div class="group-msg-header">
        <span class="group-msg-name" style="color:${msg.color || '#00f0ff'}">${esc(msg.from)}</span>
      </div>
      <div class="group-msg-text">${esc(msg.content)}</div>`;
    container.appendChild(item);
  });
  container.scrollTop = container.scrollHeight;
}

async function sendGroupMessage() {
  const input = $('group-input');
  const text = input.value.trim();
  if (!text || !state.activeRoomId) return;
  input.value = '';

  addRoomMessage(state.activeRoomId, { from: 'You', content: text, color: '#00f0ff', isUser: true });

  try {
    const replies = await POST(`/rooms/${state.activeRoomId}/message`, { message: text, fromUser: 'User' });
    replies.forEach(r => addRoomMessage(state.activeRoomId, {
      from: `${r.agentEmoji} ${r.agentName}`,
      content: r.message,
      color: '#a0a0a0',
      isUser: false,
    }));
  } catch (e) {
    addRoomMessage(state.activeRoomId, { from: 'System', content: `Error: ${e.message}`, color: '#ff4466', isUser: false });
  }
}

async function deleteRoom(roomId) {
  if (!confirm('Delete this room?')) return;
  await DEL(`/rooms/${roomId}`);
  if (state.activeRoomId === roomId) { state.activeRoomId = null; state.view = 'agents'; }
  await loadRooms();
}

// ─── Create Room Modal ────────────────────────────────────────────────────────
function openCreateRoomModal() {
  const body = $('create-room-body');
  body.innerHTML = `
    <div class="field">
      <label class="field-label">Room Name</label>
      <input class="field-input" id="room-name-input" placeholder="e.g. brainstorm" />
    </div>
    <div class="field">
      <label class="field-label">Select Agents</label>
      <div id="room-agent-checks" class="cap-grid"></div>
    </div>`;

  const checks = $('room-agent-checks');
  state.agents.forEach(agent => {
    const label = el('label', 'cap-check');
    label.innerHTML = `<input type="checkbox" value="${agent.id}" /> ${agent.emoji} ${esc(agent.name)}`;
    label.querySelector('input').addEventListener('change', () => label.classList.toggle('checked', label.querySelector('input').checked));
    checks.appendChild(label);
  });

  $('create-room-modal').classList.remove('hidden');
}

async function submitCreateRoom() {
  const name = $('room-name-input').value.trim();
  if (!name) return;
  const agentIds = [...document.querySelectorAll('#room-agent-checks input:checked')].map(i => i.value);
  await POST('/rooms', { name, agentIds });
  $('create-room-modal').classList.add('hidden');
  await loadRooms();
}

// ─── Create Agent Modal ───────────────────────────────────────────────────────
const COLOR_PRESETS = ['#00f0ff', '#a855f7', '#22d3ee', '#f59e0b', '#10b981', '#f43f5e', '#6366f1', '#84cc16'];
const CAPS = ['web_access', 'terminal', 'voice', 'image_gen', 'file_edit', 'group_chat'];
let selectedColor = COLOR_PRESETS[0];

function openCreateAgentModal() {
  $('ca-name').value = '';
  $('ca-emoji').value = '🤖';
  $('ca-personality').value = '';
  $('ca-apikey').value = '';
  $('ca-model').value = 'gpt-4o-mini';
  selectedColor = COLOR_PRESETS[0];
  updateColorSwatch();

  const checkGrid = $('ca-caps');
  checkGrid.innerHTML = '';
  CAPS.forEach(cap => {
    const label = el('label', 'cap-check');
    label.innerHTML = `<input type="checkbox" value="${cap}" /> ${cap.replace('_', ' ')}`;
    const checkbox = label.querySelector('input');
    if (cap === 'group_chat') { checkbox.checked = true; label.classList.add('checked'); }
    checkbox.addEventListener('change', () => label.classList.toggle('checked', checkbox.checked));
    checkGrid.appendChild(label);
  });

  $('create-agent-modal').classList.remove('hidden');
  $('ca-name').focus();
}

function updateColorSwatch() {
  $('ca-color-swatch').style.background = selectedColor;
  document.querySelectorAll('.color-preset').forEach(p => {
    p.classList.toggle('selected', p.dataset.color === selectedColor);
  });
}

async function submitCreateAgent() {
  const name = $('ca-name').value.trim();
  if (!name) { $('ca-name').focus(); return; }

  const capabilities = [...document.querySelectorAll('#ca-caps input:checked')].map(i => i.value);

  const agent = {
    name,
    emoji: $('ca-emoji').value.trim() || '🤖',
    color: selectedColor,
    personality: $('ca-personality').value.trim() || `I am ${name}, a helpful AI assistant.`,
    capabilities,
    apiKey: $('ca-apikey').value.trim(),
    model: $('ca-model').value || 'gpt-4o-mini',
  };

  $('btn-create-agent-submit').disabled = true;
  $('btn-create-agent-submit').textContent = 'Creating...';

  try {
    const created = await POST('/agents', agent);
    $('create-agent-modal').classList.add('hidden');
    await loadAgents();
    selectAgent(created.id);
  } catch (e) {
    alert(`Failed to create agent: ${e.message}`);
  } finally {
    $('btn-create-agent-submit').disabled = false;
    $('btn-create-agent-submit').textContent = 'Create Agent';
  }
}

async function deleteCurrentAgent() {
  if (!state.activeAgentId) return;
  const agent = getAgent(state.activeAgentId);
  if (!confirm(`Delete agent "${agent?.name}"?`)) return;
  await DEL(`/agents/${state.activeAgentId}`);
  state.activeAgentId = null;
  await loadAgents();
  renderWorkspace();
}

// ─── PIN Modal ───────────────────────────────────────────────────────────────
function openPinModal() {
  state.pinBuffer = '';
  $('pin-error').textContent = '';
  updatePinDots();
  $('pin-modal').classList.remove('hidden');
}

function closePinModal() {
  $('pin-modal').classList.add('hidden');
  state.pinBuffer = '';
  state.pendingCommand = null;
}

function pinKeyPress(val) {
  if (val === 'DEL') {
    state.pinBuffer = state.pinBuffer.slice(0, -1);
  } else if (val === 'OK' || state.pinBuffer.length >= 6) {
    submitPin();
    return;
  } else {
    if (state.pinBuffer.length < 6) state.pinBuffer += val;
  }
  updatePinDots();
  if (state.pinBuffer.length >= 4 && val !== 'DEL') submitPin();
}

function updatePinDots() {
  document.querySelectorAll('.pin-dot').forEach((dot, i) => {
    dot.classList.toggle('filled', i < state.pinBuffer.length);
  });
}

async function submitPin() {
  const pin = state.pinBuffer;
  state.pinBuffer = '';
  $('pin-modal').classList.add('hidden');
  await executePendingCommand(pin);
}

// ─── Tools ───────────────────────────────────────────────────────────────────
async function loadTools() {
  try {
    const res = await GET('/tools/sync');
    state.tools = res.tools || [];
    const list = $('toolbox-list');
    if (!list) return;
    list.innerHTML = '';
    state.tools.forEach(tool => {
      const item = el('div', 'tool-item');
      item.innerHTML = `<span class="tool-icon">⚙</span> ${esc(tool)}`;
      list.appendChild(item);
    });
  } catch (_) {}
}

// ─── Global Events ───────────────────────────────────────────────────────────
function bindGlobalEvents() {
  // Chat send
  $('btn-send').addEventListener('click', sendMessage);
  $('chat-input').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });
  $('chat-input').addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
  });

  // Terminal
  $('terminal-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') runTerminalCommand();
  });

  // Voice
  $('voice-btn').addEventListener('click', toggleVoice);

  // Group chat
  $('group-input').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendGroupMessage(); }
  });
  $('btn-group-send').addEventListener('click', sendGroupMessage);

  // Sidebar toggle
  $('sidebar-toggle').addEventListener('click', () => {
    $('sidebar').classList.toggle('collapsed');
  });

  // Create agent modal
  $('btn-new-agent').addEventListener('click', openCreateAgentModal);
  $('btn-create-agent-submit').addEventListener('click', submitCreateAgent);
  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => document.getElementById(btn.dataset.closeModal).classList.add('hidden'));
  });

  // Color presets
  document.querySelectorAll('.color-preset').forEach(p => {
    p.addEventListener('click', () => { selectedColor = p.dataset.color; updateColorSwatch(); });
  });
  $('ca-color-swatch').addEventListener('click', () => {
    const picker = el('input'); picker.type = 'color'; picker.value = selectedColor;
    picker.addEventListener('input', () => { selectedColor = picker.value; updateColorSwatch(); });
    picker.click();
  });

  // Create room modal
  $('btn-new-room').addEventListener('click', openCreateRoomModal);
  $('btn-create-room-submit').addEventListener('click', submitCreateRoom);

  // Delete agent
  $('btn-delete-agent')?.addEventListener('click', deleteCurrentAgent);

  // PIN numpad
  document.querySelectorAll('.pin-key').forEach(btn => {
    btn.addEventListener('click', () => pinKeyPress(btn.dataset.val));
  });

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.add('hidden');
    });
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay:not(.hidden)').forEach(m => m.classList.add('hidden'));
      if ($('pin-modal') && !$('pin-modal').classList.contains('hidden')) closePinModal();
    }
  });

  // Rooms nav
  $('nav-agents')?.addEventListener('click', () => { state.view = 'agents'; renderWorkspace(); });
  $('nav-rooms')?.addEventListener('click', () => { state.view = 'rooms'; renderWorkspace(); });
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function esc(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
