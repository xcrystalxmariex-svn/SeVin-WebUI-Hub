#!/bin/bash
# SeVIn AI Hub — Dependency Checker and Setup Script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "╔═══════════════════════════════════════════════╗"
echo "║        SeVIn AI Hub — Setup Wizard            ║"
echo "╚═══════════════════════════════════════════════╝"
echo ""
echo "  Hub directory: $SCRIPT_DIR"
echo ""

# ── Dependency checks ─────────────────────────────────────────────────────
check_dep() {
    if command -v "$1" &> /dev/null; then
        echo "  ✓ $1  ($(command -v "$1"))"
        return 0
    else
        echo "  ✗ $1  NOT found"
        return 1
    fi
}

echo "Checking dependencies..."
echo ""

MISSING_DEPS=0
check_dep python3 || MISSING_DEPS=1
check_dep pip3 || check_dep pip || MISSING_DEPS=1
check_dep tmux || {
    echo ""
    echo "  tmux is required. Install it:"
    echo "    Termux: pkg install tmux"
    echo "    Debian: sudo apt install tmux"
    MISSING_DEPS=1
}

if [ $MISSING_DEPS -eq 1 ]; then
    echo ""
    echo "Please install missing dependencies and re-run this script."
    echo "  Termux quick install:"
    echo "    pkg update && pkg install python tmux"
    exit 1
fi

# ── Python packages ───────────────────────────────────────────────────────
echo ""
echo "Installing Python packages..."
echo ""

PIP_CMD="pip3"
command -v pip3 &> /dev/null || PIP_CMD="pip"

PACKAGES=(flask flask-socketio flask-cors requests gTTS edge-tts pypdf)

for pkg in "${PACKAGES[@]}"; do
    echo -n "  $pkg ... "
    if $PIP_CMD install "$pkg" --quiet --disable-pip-version-check 2>/dev/null; then
        echo "✓"
    else
        echo "⚠ (skipped)"
    fi
done

mkdir -p generated_agents data

# ── Agent setup ───────────────────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [ ! -f "agents.json" ] || [ "$(python3 -c "import json; print(len(json.load(open('agents.json'))))" 2>/dev/null)" = "0" ]; then
    echo "No agents configured yet. Running setup wizard..."
    echo ""
    python3 setup_wizard.py
else
    AGENT_COUNT=$(python3 -c "import json; print(len(json.load(open('agents.json'))))")
    echo "Agents found: $AGENT_COUNT"
    echo ""
    echo "  1. Launch the hub (use existing agents)"
    echo "  2. Add / reconfigure agents first"
    echo "  3. Exit"
    echo ""
    read -p "Choose [1]: " CHOICE
    CHOICE="${CHOICE:-1}"

    if [ "$CHOICE" = "2" ]; then
        python3 setup_wizard.py
    elif [ "$CHOICE" = "3" ]; then
        exit 0
    fi
fi

# ── Generate agent files ──────────────────────────────────────────────────
echo ""
echo "Generating agent files..."
python3 agent_factory.py agents.json generated_agents/ 2>/dev/null \
    && echo "  ✓ Agent files ready" \
    || echo "  (Skipped — will be auto-generated on launch)"

# ── Launch ────────────────────────────────────────────────────────────────
echo ""
echo "Launching SeVIn AI Hub..."
python3 launch_system.py --start

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  Hub running at: http://localhost:8080"
echo ""
echo "  View logs : tmux attach -t sevin-hub"
echo "  Stop      : python3 launch_system.py --stop"
echo "  Status    : python3 launch_system.py --status"
echo ""
