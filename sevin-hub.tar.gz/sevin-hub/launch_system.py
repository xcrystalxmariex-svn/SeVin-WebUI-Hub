#!/usr/bin/env python3
"""
SeVIn AI Hub — Launch System Manager
Manages tmux sessions for the hub and all agents.
"""

import argparse
import json
import os
import shlex
import subprocess
import sys
import time
import uuid

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
AGENTS_FILE = os.path.join(BASE_DIR, "agents.json")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
GEN_DIR     = os.path.join(BASE_DIR, "generated_agents")
SESSION     = "sevin-hub"

# Use python3 if available, fall back to python
PYTHON = (
    "python3"
    if subprocess.run(["which", "python3"], capture_output=True).returncode == 0
    else "python"
)


# ── Safe tmux helpers ──────────────────────────────────────────────────────

def tmux(*args) -> subprocess.CompletedProcess:
    """Run a tmux sub-command safely (no shell quoting issues)."""
    return subprocess.run(["tmux"] + list(args), capture_output=True, text=True)


def tmux_send(window: str, cmd: str):
    """Type a command into a tmux window and press Enter.
    The command string is passed as a single argument — no shell escaping needed.
    """
    subprocess.run(
        ["tmux", "send-keys", "-t", f"{SESSION}:{window}", cmd, "Enter"],
        capture_output=True,
    )


def session_exists() -> bool:
    return tmux("has-session", "-t", SESSION).returncode == 0


# ── Data helpers ───────────────────────────────────────────────────────────

def load_agents() -> list:
    if not os.path.exists(AGENTS_FILE):
        return []
    try:
        with open(AGENTS_FILE) as f:
            return json.load(f)
    except Exception:
        return []


def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def agent_safe_name(name: str) -> str:
    return name.replace(" ", "_").replace("-", "_").lower()


# ── Agent file generation ─────────────────────────────────────────────────

def ensure_agent_files(agents: list) -> list:
    """Generate missing agent Python files; return only agents with valid files."""
    sys.path.insert(0, BASE_DIR)
    try:
        from agent_factory import AgentFactory
        factory = AgentFactory(GEN_DIR)
    except ImportError:
        print("  ⚠ agent_factory.py not found — skipping auto-generation")
        return agents

    os.makedirs(GEN_DIR, exist_ok=True)
    ready = []
    for agent in agents:
        safe       = agent_safe_name(agent["name"])
        agent_file = os.path.join(GEN_DIR, f"{safe}_main.py")
        if not os.path.exists(agent_file):
            print(f"  Generating {agent['emoji']} {agent['name']}...")
            try:
                factory.create_agent(agent)
            except Exception as e:
                print(f"  ⚠ Could not generate file for {agent['name']}: {e}")
                continue
        ready.append(agent)
    return ready


# ── Commands ───────────────────────────────────────────────────────────────

def start():
    if session_exists():
        print(f"Session '{SESSION}' is already running.")
        print(f"  View  : tmux attach -t {SESSION}")
        print(f"  Restart: python3 {os.path.basename(__file__)} --restart")
        return

    agents = load_agents()
    if not agents:
        print("⚠  No agents found in agents.json.")
        print()
        print("   Create at least one agent first:")
        print(f"   python3 {shlex.quote(os.path.join(BASE_DIR, 'setup_wizard.py'))}")
        print()
        choice = input("   Run setup_wizard now? [Y/n]: ").strip().lower()
        if choice not in ("n", "no"):
            wizard = os.path.join(BASE_DIR, "setup_wizard.py")
            os.execv(sys.executable, [sys.executable, wizard])
        return

    config   = load_config()
    hub_port = config.get("hub_port", 8080)

    agents = ensure_agent_files(agents)

    print(f"\nStarting SeVIn AI Hub...")
    print(f"  Directory : {BASE_DIR}")
    print(f"  Hub port  : {hub_port}")
    print(f"  Agents    : {len(agents)}")
    print()

    # Hub window — cd using the full absolute path passed as a proper command
    tmux("new-session", "-d", "-s", SESSION, "-n", "hub")
    hub_py  = os.path.join(BASE_DIR, "hub_server.py")
    hub_cmd = f"cd {shlex.quote(BASE_DIR)} && {PYTHON} {shlex.quote(hub_py)}"
    tmux_send("hub", hub_cmd)
    print(f"  ✓ Hub server started (window: hub)")

    time.sleep(1)  # let hub bind its port

    for i, agent in enumerate(agents, 1):
        safe       = agent_safe_name(agent["name"])
        agent_file = os.path.join(GEN_DIR, f"{safe}_main.py")
        win        = f"agent-{i}"

        tmux("new-window", "-t", SESSION, "-n", win)

        if os.path.exists(agent_file):
            agent_cmd = (
                f"cd {shlex.quote(BASE_DIR)} && "
                f"{PYTHON} {shlex.quote(agent_file)}"
            )
            tmux_send(win, agent_cmd)
            print(f"  ✓ {agent['emoji']} {agent['name']}  →  port {agent['port']}  (window: {win})")
        else:
            tmux_send(win, f"echo 'ERROR: agent file not found: {agent_file}'")
            print(f"  ✗ {agent['name']} — file missing: {agent_file}")

    print(f"""
✓ SeVIn AI Hub is running!

  Open    : http://localhost:{hub_port}
  Attach  : tmux attach -t {SESSION}
  Stop    : python3 launch_system.py --stop
""")


def stop():
    if not session_exists():
        print(f"Session '{SESSION}' is not running.")
        return
    tmux("kill-session", "-t", SESSION)
    print(f"✓ Stopped '{SESSION}'")


def status():
    if not session_exists():
        print("Status: NOT running")
        print(f"  Start : python3 {os.path.basename(__file__)} --start")
        return

    print(f"Status: RUNNING  (session: {SESSION})")
    result = tmux("list-windows", "-t", SESSION)
    if result.stdout:
        print("\nWindows:")
        for line in result.stdout.strip().split("\n"):
            print(f"  {line}")

    agents = load_agents()
    config = load_config()
    print(f"\nDirectory  : {BASE_DIR}")
    print(f"Hub port   : {config.get('hub_port', 8080)}")
    print(f"Agents     : {len(agents)}")


def add_agent_cmd(name, emoji="🤖", color="#6366f1",
                  personality="", capabilities=None, port=None,
                  model="gpt-4o-mini"):
    agents    = load_agents()
    used_ports = {a["port"] for a in agents}

    if port is None:
        port = 8001
        while port in used_ports:
            port += 1

    agent = {
        "id":           str(uuid.uuid4()),
        "name":         name,
        "emoji":        emoji,
        "color":        color,
        "personality":  personality or f"I am {name}, a helpful AI assistant.",
        "capabilities": capabilities or ["group_chat"],
        "port":         port,
        "status":       "offline",
        "model":        model,
    }
    agents.append(agent)

    with open(AGENTS_FILE, "w") as f:
        json.dump(agents, f, indent=2)
    print(f"✓ Agent '{emoji} {name}' saved (port {port})")

    sys.path.insert(0, BASE_DIR)
    try:
        from agent_factory import AgentFactory
        AgentFactory(GEN_DIR).create_agent(agent)
        print("✓ Agent file generated")
    except Exception as e:
        print(f"⚠ Could not generate agent file: {e}")

    if session_exists():
        win        = f"agent-{len(agents)}"
        safe       = agent_safe_name(name)
        agent_file = os.path.join(GEN_DIR, f"{safe}_main.py")
        tmux("new-window", "-t", SESSION, "-n", win)
        if os.path.exists(agent_file):
            agent_cmd = (
                f"cd {shlex.quote(BASE_DIR)} && "
                f"{PYTHON} {shlex.quote(agent_file)}"
            )
            tmux_send(win, agent_cmd)
            print(f"✓ Agent started in tmux window '{win}'")
        else:
            print("⚠ Agent file not found — not started in tmux")
    else:
        print("  (Hub not running — start with: python3 launch_system.py --start)")


# ── Entry point ────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="SeVIn AI Hub Launch System")
    parser.add_argument("--start",        action="store_true", help="Start hub + all agents")
    parser.add_argument("--stop",         action="store_true", help="Stop everything")
    parser.add_argument("--status",       action="store_true", help="Show status")
    parser.add_argument("--restart",      action="store_true", help="Stop then start")
    parser.add_argument("--add-agent",    metavar="NAME",      help="Add and start a new agent")
    parser.add_argument("--emoji",        default="🤖")
    parser.add_argument("--color",        default="#6366f1")
    parser.add_argument("--personality",  default="")
    parser.add_argument("--capabilities", nargs="+",
                        choices=["web_access", "terminal", "voice", "image_gen",
                                 "file_edit", "group_chat"])
    parser.add_argument("--port",         type=int)
    parser.add_argument("--model",        default="gpt-4o-mini")
    args = parser.parse_args()

    if args.start:
        start()
    elif args.stop:
        stop()
    elif args.restart:
        stop()
        time.sleep(1)
        start()
    elif args.status:
        status()
    elif args.add_agent:
        add_agent_cmd(
            args.add_agent,
            emoji=args.emoji,
            color=args.color,
            personality=args.personality,
            capabilities=args.capabilities,
            port=args.port,
            model=args.model,
        )
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
